package com.nie.csd.exceptions;

public class IdNotPresentException extends Exception {
    public IdNotPresentException(String message) {
        super(message);
    }
    
}
